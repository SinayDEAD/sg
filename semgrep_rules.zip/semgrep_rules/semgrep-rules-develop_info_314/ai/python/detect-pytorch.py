# ruleid: detect-pytorch
import torch
# ruleid: detect-pytorch
x = torch.rand(5, 3)
print(x)